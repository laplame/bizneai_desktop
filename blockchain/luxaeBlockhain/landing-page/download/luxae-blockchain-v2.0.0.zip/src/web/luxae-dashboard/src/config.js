export const API_URL = 'http://localhost:3000/api'; // API de la blockchain
export const DASHBOARD_URL = 'http://localhost:3001'; // Dashboard 